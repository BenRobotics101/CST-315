# Deadlock Avoidance
# By: Trevor Pope and Ben Carter

# To Build:
run `make`. It will output two executables: `case1` and `case2_fixed`.

Github Link: https://github.com/BenRobotics101/CST-315
